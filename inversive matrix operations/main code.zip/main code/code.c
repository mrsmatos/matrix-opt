#include <stdio.h>
#include <stdlib.h>

char my_type[] = "%lf";
#define MAX_SIZE 10

// Structure to hold a matrix
typedef struct {
    double** data;
    double *u, *v, value;
    int i, j;
    int size;
} Matrix;

// Function to allocate memory for a matrix
Matrix* allocateMatrix(int size) {
    Matrix* matrix = (Matrix*)malloc(sizeof(Matrix));
    matrix->data = (double**)malloc(size * sizeof(double*));
    matrix->u = (double*)malloc(size * sizeof(double));
    matrix->v = (double*)malloc(size * sizeof(double));
    for (int i = 0; i < size; i++) {
        matrix->data[i] = (double*)malloc(size * sizeof(double));
        matrix->u[i] = matrix->v[i] = 0.0; 
    }
    matrix->size = size;
    return matrix;
}

// Function to free memory allocated for a matrix
void freeMatrix(Matrix* matrix) {
    for (int i = 0; i < matrix->size; i++) {
        free(matrix->data[i]);
    }
    free(matrix->data);
    free(matrix->u);
    free(matrix->v);
    free(matrix);
}

// Function to print a matrix
void printMatrix(Matrix* matrix) {
    for (int i = 0; i < matrix->size; i++) {
        for (int j = 0; j < matrix->size; j++) {
            printf("%lf ", matrix->data[i][j]);
        }
        printf("\n");
    }
}

// Function to read a matrix from keyboard (i.e. by scanf or input like file.in)
int read_matrix_from_keyboard(Matrix** matrix, Matrix** inverse_matrix) {
    int size;
    scanf("%d", &size);  // Read the size of the matrix
    
    (*matrix) = allocateMatrix(size);
    (*inverse_matrix) = allocateMatrix(size);
    if (matrix==NULL || inverse_matrix==NULL)
        return -1;
    
    (*matrix)->size = size; 
    (*inverse_matrix)->size = size;

    // Read values for the matrix
    for (int i = 0; i < size; i++) {
        for (int j = 0; j < size; j++) {
            scanf("%lf", &(*matrix)->data[i][j]);
        }
    }

    scanf("%d", &size);  // Read the size of the inverse matrix
    // Read values for the inverse matrix
    for (int i = 0; i < size; i++) {
        for (int j = 0; j < size; j++) {
            scanf("%lf", &(*inverse_matrix)->data[i][j]);
        }
    }

    //for (int i = 0; i < size; i++) scanf("%d", &matrix->u[i]);
    //for (int i = 0; i < size; i++) scanf("%d", &matrix->v[i]);

    // Read index and value to change in original matrix
    scanf("%d", &(*matrix)->i);
    scanf("%d", &(*matrix)->j);
    scanf("%lf", &(*matrix)->value);
    return 0;
}

// Function to update the inverse matrix using Sherman-Morrison formula
// void updateInverseMatrix(int n, double A[][n], double invA[][n], double v[], double u[])
void updateInverseMatrix(Matrix* matrix, Matrix* inverse_matrix) {
    int n = matrix->size;
    double alpha = 1.0, beta = 1.0, gamma = 1.0;
    double w[n][n];

    // Calculate the intermediate matrix w
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            if (i == j)
                w[i][j] = 1.0 / (matrix->v[i] - beta);
            else
                w[i][j] = 0.0;
        }
    }

    // Update the inverse matrix using Sherman-Morrison formula
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            inverse_matrix->data[i][j] = inverse_matrix->data[i][j] - (matrix->u[i] * w[j][i]);
        }
    }

    // Calculate the intermediate values alpha and beta
    alpha = 1.0 / (1.0 - (beta * matrix->u[0]));
    beta = matrix->u[0];

    // Update the inverse matrix using Sherman-Morrison formula
    for (int i = 0; i < n; i++) {
        inverse_matrix->data[i][0] = alpha * inverse_matrix->data[i][0];
    }

    // Update the inverse matrix using Sherman-Morrison formula
    for (int i = 1; i < n; i++) {
        gamma = inverse_matrix->data[i][0];
        for (int j = 0; j < n; j++) {
            inverse_matrix->data[j][i] = inverse_matrix->data[j][i] + (gamma * matrix->u[j]);
        }
    }
}

// Function to update VALUE the inverse matrix using Sherman-Morrison formula
void updateInverse_ONE_VALUE(Matrix** original, Matrix** inverse, int row, int column, double value) {
    double alpha = ((double) 1.0 ) / (value - (*original)->data[row][column]);
    
    // Update inverse matrix using Sherman-Morrison formula
    for (int i = 0; i < (*inverse)->size; i++) {
        for (int j = 0; j < (*inverse)->size; j++) {
            if (i == row && j == column) {
                (*inverse)->data[i][j] += alpha;
            } else {                
                (*inverse)->data[i][j] -= (alpha * (*original)->data[i][column] * (*inverse)->data[row][j]) / (1 + alpha * (*original)->data[row][column]);
            }
        }
    }
}

// Function to update ONE VECTOR the inverse matrix using Sherman-Morrison formula
void updateInverseMatrix_ONE_VECTOR(Matrix *inverse, double *columnVector, int index) {
    int size = inverse->size;
    
    // Compute the intermediate values for the Sherman-Morrison formula
    double *v = (double*)malloc(size * sizeof(double));
    double *u = (double*)malloc(size * sizeof(double));
    
    for (int i = 0; i < size; i++) {
        v[i] = 0.0;
        u[i] = inverse->data[i][index] / inverse->data[index][index];
    }
    u[index] = 1.0 / inverse->data[index][index];
    
    // Compute the updated inverse matrix using the Sherman-Morrison formula
    for (int i = 0; i < size; i++) {
        for (int j = 0; j < size; j++) {
            if (i != index && j != index) {
                inverse->data[i][j] = inverse->data[i][j] - u[i] * inverse->data[index][j] * v[j];
            }
        }
    }
    
    for (int i = 0; i < size; i++) {
        if (i != index) {
            inverse->data[i][index] = -u[i] * v[index];
            inverse->data[index][i] = -u[index] * v[i];
        }
    }
    
    inverse->data[index][index] = u[index];
    
    // Update the inverse matrix with the new column vector
    for (int i = 0; i < size; i++) {
        inverse->data[i][index] += u[i] * columnVector[i];
    }
    
    free(u);
    free(v);
}

// Function to update TWO VECTOR the inverse matrix using Sherman-Morrison formula v 1.0
void updateInverseMatrix_TWO_VECTOR(double **A_inv, double **A, double *rowVector, double *colVector, int n) {
    double factor1 = 0.0;
    double factor2 = 0.0;
    double *temp1 = (double*)malloc(n * sizeof(double));
    double *temp2 = (double*)malloc(n * sizeof(double));

    // Calculate the factors: factor1 = 1 / (1 + colVector * A_inv * rowVector) and factor2 = -1 / (1 + rowVector * A_inv * colVector)
    for (int i = 0; i < n; i++) {
        temp1[i] = 0.0;
        temp2[i] = 0.0;
        for (int j = 0; j < n; j++) {
            temp1[i] += colVector[j] * A_inv[j][i];
            temp2[i] += rowVector[j] * A_inv[j][i];
        }
    }

    for (int i = 0; i < n; i++) {
        factor1 += temp1[i] * rowVector[i];
        factor2 += temp2[i] * colVector[i];
    }
    factor1 = 1.0 / (1.0 + factor1);
    factor2 = -1.0 / (1.0 + factor2);

    // Update the inverse matrix: A_inv = A_inv + factor1 * A_inv * rowVector * colVector * A_inv
    double **temp3 = (double**)malloc(n * sizeof(double*));
    for (int i = 0; i < n; i++) {
        temp3[i] = (double*)malloc(n * sizeof(double));
    }

    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            temp3[i][j] = 0.0;
            for (int k = 0; k < n; k++) {
                temp3[i][j] += A_inv[i][k] * rowVector[k] * colVector[j];
            }
            temp3[i][j] *= factor1;
            A_inv[i][j] += temp3[i][j];
        }
    }

    // Update the inverse matrix: A_inv = A_inv + factor2 * A_inv * colVector * rowVector * A_inv
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            temp3[i][j] = 0.0;
            for (int k = 0; k < n; k++) {
                temp3[i][j] += A_inv[i][k] * colVector[k] * rowVector[j];
            }
            temp3[i][j] *= factor2;
            A_inv[i][j] += temp3[i][j];
        }
    }

    // Free the temporary memory
    for (int i = 0; i < n; i++) {
        free(temp3[i]);
    }
    free(temp3);
    free(temp1);
    free(temp2);
}

// Function to update TWO VECTOR the inverse matrix using Sherman-Morrison formula v 2.0
void updateInverseMatrix_TWO_VECTOR2(double **A_inv, double **A, double *u, double *v, int n) {
    double factor = 0.0;
    double *temp1 = (double*)malloc(n * sizeof(double));
    double *temp2 = (double*)malloc(n * sizeof(double));

    // Calculate the factors: factor = 1 / (1 + v * A_inv * u)
    for (int i = 0; i < n; i++) {
        temp1[i] = 0.0;
        temp2[i] = 0.0;
        for (int j = 0; j < n; j++) {
            temp1[i] += v[j] * A_inv[j][i];
            temp2[i] += A_inv[i][j] * u[j];
        }
    }

    for (int i = 0; i < n; i++) {
        factor += temp1[i] * u[i];
        factor += v[i] * temp2[i];
    }
    factor = 1.0 / (1.0 + factor);

    // Calculate A_inv = A_inv - (A_inv * u * v * A_inv) / (1 + v * A_inv * u)
    double **temp3 = (double**)malloc(n * sizeof(double*));
    for (int i = 0; i < n; i++) {
        temp3[i] = (double*)malloc(n * sizeof(double));
    }

    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            temp3[i][j] = 0.0;
            for (int k = 0; k < n; k++) {
                temp3[i][j] += A_inv[i][k] * u[k] * v[j];
            }
            temp3[i][j] *= factor;
            A_inv[i][j] -= temp3[i][j];
        }
    }

    // Free the temporary memory
    for (int i = 0; i < n; i++) {
        free(temp3[i]);
    }
    free(temp3);
    free(temp1);
    free(temp2);
}

//////////////////////////////////// NEW //////////////////////////////////////////////////////////
void updateInverseMatrix0(double** invMatrix, double* column, int size) {
    // Allocate memory for temporary matrices
    double** tempMatrix = (double**)malloc(size * sizeof(double*));
    double* tempVector = (double*)malloc(size * sizeof(double));
    double tempValue = 0.0;

    // Compute the intermediate values required for the update
    for (int i = 0; i < size; i++) {
        tempMatrix[i] = (double*)malloc(size * sizeof(double));
        for (int j = 0; j < size; j++) {
            tempMatrix[i][j] = invMatrix[i][j] * column[j];
            tempValue += tempMatrix[i][j];
        }
        tempVector[i] = tempValue;
        tempValue = 0.0;
    }

    // Compute the Sherman-Morrison update
    double denominator = 1.0 / (1.0 + tempVector[0]);
    for (int i = 0; i < size; i++) {
        for (int j = 0; j < size; j++) {
            if (i == 0) {
                invMatrix[i][j] -= (tempMatrix[i][j] * denominator);
            } else {
                invMatrix[i][j] -= ((tempMatrix[i][j] * tempVector[i-1]) / (1.0 + tempVector[0]));
            }
        }
    }

    // Free temporary matrices
    for (int i = 0; i < size; i++) {
        free(tempMatrix[i]);
    }
    free(tempMatrix);
    free(tempVector);
}

void updateInverseMatrix1(double** invMatrix, int size, double* vector) {
    int i, j;
    double* u = (double*)malloc(size * sizeof(double));
    double* v = (double*)malloc(size * sizeof(double));

    // Calculate u = invMatrix * vector
    for (i = 0; i < size; i++) {
        u[i] = 0.0;
        for (j = 0; j < size; j++) {
            u[i] += invMatrix[i][j] * vector[j];
        }
    }

    // Calculate v = vector * invMatrix
    double denominator = 0.0;
    for (i = 0; i < size; i++) {
        v[i] = vector[i];
        denominator += u[i] * vector[i];
    }

    // Calculate the updated inverse matrix
    for (i = 0; i < size; i++) {
        for (j = 0; j < size; j++) {
            invMatrix[i][j] -= (u[i] * v[j]) / denominator;
        }
    }

    free(u);
    free(v);
}

void updateInverseMatrix2(double A[MAX_SIZE][MAX_SIZE], double invA[MAX_SIZE][MAX_SIZE], int size, int row, int col, double newValue) {
    // Compute the Sherman-Morrison correction factor
    double factor = 1.0 / (newValue - A[row][col]);

    // Update the inverse matrix
    for (int i = 0; i < size; i++) {
        for (int j = 0; j < size; j++) {
            if (i == row && j == col) {
                // Update the (row, col) element using the Sherman-Morrison formula
                invA[i][j] += factor * invA[i][j] * A[row][col];
            } else {
                // Update other elements based on the Sherman-Morrison formula
                invA[i][j] -= factor * invA[i][col] * A[row][j];
                invA[i][j] -= factor * A[i][col] * invA[row][j];
            }
        }
    }

    // Add the new column and row to the original matrix
    A[row][col] = newValue;
    for (int i = 0; i < size; i++) {
        if (i != row) {
            A[i][col] = 0.0;
        }
        if (i != col) {
            A[row][i] = 0.0;
        }
    }
}

//////////////////////////////////////////////////////////////////////////////////////////////
// TODO: Function to read a matrix from a file
Matrix* readMatrixFromFile(int argc, const char* filename) {
    FILE* file = fopen(filename, "r");
    if (file == NULL) {
        printf("Error opening the file.\n");
        return NULL;
    }

    int size;
    fscanf(file, "%d", &size);  // Read the size of the matrix

    Matrix* matrix = allocateMatrix(size);

    // Read values for the matrix
    for (int i = 0; i < size; i++) {
        for (int j = 0; j < size; j++) {
            fscanf(file, "%lf", &matrix->data[i][j]);
        }
    }

    fscanf(file, "%d", &size);  // Read the size of the inverse matrix
    // Read values for the inverse matrix
    for (int i = 0; i < size; i++) {
        for (int j = 0; j < size; j++) {
            fscanf(file, "%d", &size);
        }
    }
    fscanf(file, "%d", &size);  // Read index and value to change in original matrix
    fscanf(file, "%d", &size);
    fscanf(file, "%d", &size);

    fclose(file);
    return matrix;
}

// TODO: ...
double dotProduct(double* u, double* v, int size) {
    double result = 0.0;
    for (int i = 0; i < size; i++) {
        result += u[i] * v[i];
    }
    return result;
}

// TODO: Function to compute the inverse of a matrix using the Sherman-Morrison formula 1
Matrix* calculateInverse(Matrix* matrix, int rowIndex, int colIndex, double newValue) {
    int size = matrix->size;
    Matrix* inverse = allocateMatrix(size);

    // Initialize the inverse matrix as the identity matrix
    for (int i = 0; i < size; i++) {
        for (int j = 0; j < size; j++) {
            inverse->data[i][j] = (i == j) ? 1.0 : 0.0;
        }
    }

    // Perform Sherman-Morrison algorithm to update the inverse matrix
    double* u = (double*)malloc(size * sizeof(double));
    double* v = (double*)malloc(size * sizeof(double));

    // Calculate u and v vectors
    for (int i = 0; i < size; i++) {
        u[i] = matrix->data[i][colIndex];
        v[i] = matrix->data[rowIndex][i];
    }

    // Calculate the denominator term in the Sherman-Morrison formula
    double denominator = 1.0 + dotProduct(u, v, size);

    // Calculate the numerator matrix
    Matrix* numeratorMatrix = allocateMatrix(size);
    for (int i = 0; i < size; i++) {
        for (int j = 0; j < size; j++) {
            numeratorMatrix->data[i][j] = -matrix->data[i][colIndex] * matrix->data[rowIndex][j];
        }
    }

    // Calculate the updated inverse matrix using the Sherman-Morrison formula
    for (int i = 0; i < size; i++) {
        for (int j = 0; j < size; j++) {
            inverse->data[i][j] = inverse->data[i][j] + (numeratorMatrix->data[i][j] / denominator);
        }
    }

    freeMatrix(numeratorMatrix);
    free(u);
    free(v);

    return inverse;
}

/*
// Function to compute the inverse of a matrix using the Sherman-Morrison formula 2
Matrix* calculateInverse(Matrix* matrix) {
    int size = matrix->size;
    Matrix* inverse = allocateMatrix(size);

    // Compute the inverse matrix using the Sherman-Morrison formula
    for (int i = 0; i < size; i++) {
        for (int j = 0; j < size; j++) {
            inverse->data[i][j] = (i == j) ? 1.0 : 0.0;
        }
    }

    for (int k = 0; k < size; k++) {
        double pivot = matrix->data[k][k];

        // Update the inverse matrix
        for (int i = 0; i < size; i++) {
            inverse->data[i][k] /= pivot;
        }

        // Update the matrix and inverse matrix using the Sherman-Morrison formula
        for (int i = 0; i < size; i++) {
            if (i != k) {
                double factor = matrix->data[i][k] / pivot;
                for (int j = 0; j < size; j++) {
                    matrix->data[i][j] -= factor * matrix->data[k][j];
                    inverse->data[i][j] -= factor * inverse->data[k][j];
                }
            }
        }
    }

    return inverse;
}
*/

/*
I apologize for the confusion. The Sherman-Morrison formula is typically used to update the inverse of a matrix when a new column or row is added or removed from the original matrix. It is not used to directly update a specific value in the inverse matrix.

If you want to update a specific value in the inverse matrix without altering the original matrix, you would typically use other techniques such as matrix operations or Gaussian elimination. The Sherman-Morrison formula is specifically designed for efficient updates when adding or removing columns or rows.

If you can provide more information about the specific context or problem you're trying to solve, I would be happy to assist you further.
*/

int main(int argc, char *argv[]) {
    Matrix *originalMatrix = NULL, *inverseMatrix = NULL;

    if (argc <=2){
        //read from keyborad or input file with two matrix and change command
        if (read_matrix_from_keyboard(&originalMatrix, &inverseMatrix) != -1){
            printf("Original Matrix %dx%d:\n",originalMatrix->size, originalMatrix->size);
            printMatrix(originalMatrix);

            printf("\nInverse Matrix %dx%d:\n",inverseMatrix->size, inverseMatrix->size);
            printMatrix(inverseMatrix);

            //updateInverse_ONE_VALUE(&originalMatrix, &inverseMatrix, originalMatrix->i , originalMatrix->j, originalMatrix->value);
            
            double line_vet[] = {12,  69,  68,  30,  83,  31,  63,  24,  68,  36};

            double _line_vet[] = {0.00236657, 0.00286759, 0.00390017, -0.000206773, -0.00919492, -0.000606505, 0.01009, 0.00296859, -0.000616597, -0.00655167};

            double col_vet[] = {78,       
                            91,          
                            68,          
                            23,          
                            22,          
                            92,          
                            85,          
                            83,          
                            77,          
                            77};

            double _col_vet[] = {-0.0161054,
                            0.00546049,  
                            0.00390017,  
                            0.00557017,  
                            0.0206132,   
                            0.00444797,  
                            -0.0108293,  
                            -0.00197925,
                            -0.00450104, 
                            -0.0119108};

            

            updateInverseMatrix_ONE_VECTOR(inverseMatrix, line_vet, originalMatrix->j);

            printf("\nNew Inverse Matrix:\n");
            printMatrix(inverseMatrix);
        }
        else{
            printf("ALOCATION ERROR\n");
            return 1;
        }

    }
    else{
        //read from two files, first file has main matrix and another file has inversive matrix and change command    
        originalMatrix = readMatrixFromFile(argc, argv[2]); // "matrix.in"
        if (originalMatrix == NULL) {
            printf("Error reading the matrix from the file.\n");
            return 1;
        }

        inverseMatrix = readMatrixFromFile(argc, argv[3]); // "inverse_matrix.in"

        if (inverseMatrix == NULL) {
            printf("Error reading the inverse matrix from the file.\n");
            return 1;
        }

        //printf("Original Matrix:\n");
        //printMatrix(originalMatrix);

        //printf("\nInverse Matrix:\n");
        //printMatrix(inverseMatrix);

        // Set a new value in the original matrix
        int rowIndex, colIndex;
        double newValue;
        //printf("\nEnter the row index, column index, and new value to set in the original matrix: ");
        //scanf("%d %d %lf", &rowIndex, &colIndex, &newValue);
        rowIndex = 2;
        colIndex = 2;
        newValue = 68;

        if (rowIndex >= 0 && rowIndex < originalMatrix->size && colIndex >= 0 && colIndex < originalMatrix->size) {
            // Update the original matrix
            originalMatrix->data[rowIndex][colIndex] = newValue;

            // Calculate the updated inverse matrix using the Sherman-Morrison algorithm
            Matrix* updatedInverseMatrix = calculateInverse(originalMatrix, rowIndex, colIndex, newValue);

            printf("\nMatriz Original:\n");
            printMatrix(originalMatrix);

            printf("\nNova Matriz Inversa:\n");
            printMatrix(updatedInverseMatrix);

            freeMatrix(updatedInverseMatrix);
        } else {
            printf("Invalid row or column index.\n");
        }
    }

    freeMatrix(originalMatrix);
    freeMatrix(inverseMatrix);

    return 0;
}
